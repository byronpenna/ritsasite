#include <Arduino.h>
#include <esp_heap_caps.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <nvs_flash.h>
#include <Wire.h>
#include <FS.h>
#include <SD.h>
#include <SPI.h>
#include <mbedtls/sha256.h>

#include <Adafruit_GFX.h>
#include <Adafruit_GC9A01A.h>
#include <Adafruit_SSD1306.h>

#include "hoohash_pepew.h"
#ifndef HOOHASH_PROFILE_API_V51
#error "V6: hoohash_pepew.h incorrecto/viejo. Use TODOS los archivos de esta carpeta V5.1."
#endif
#include "pepe_miner.h"

// ============================================================
//                  PEPEW ESP32-S3 V3 PERFORMANCE
// ============================================================

// -------------------- WIFI / POOL ----------------------------


static const char* POOL_HOST = "pool.pepepow.net";
static const uint16_t POOL_PORT = 39333;

static const char* WALLET =
  "PHTrCSSctLUgotckyNpFrwP1a1i2pGVX3e";

static const char* WORKER = "ESP32S3";

// ============================================================
//                      GC9A01 240x240
// ============================================================
//
// CONFIGURACION QUE YA PROBAMOS Y FUNCIONA
//
// SCLK -> GPIO15
// MOSI -> GPIO16
// DC   -> GPIO17
// CS   -> GPIO18
// RST  -> GPIO21
//

#define TFT_SCLK 15
#define TFT_MOSI 16
#define TFT_DC   17
#define TFT_CS   18
#define TFT_RST  21

Adafruit_GC9A01A tft(
  TFT_CS,
  TFT_DC,
  TFT_MOSI,
  TFT_SCLK,
  TFT_RST
);

// ============================================================
//                       OLED SSD1306
// ============================================================
//
// SDA -> GPIO1
// SCL -> GPIO2
//

#define OLED_SDA 1
#define OLED_SCL 2

#define SCREEN_WIDTH  128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 oled(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  -1
);

bool oledOK = false;

// Push button: GPIO48 -> button -> GND
#define BUTTON_PIN 48

enum OledPage : uint8_t { OLED_MAIN=0, OLED_HASHRATE=1, OLED_TOTAL=2, OLED_SHARES=3 };
volatile OledPage oledPage = OLED_MAIN;
volatile bool oledNeedsRefresh = true;
uint32_t lastButtonActivity = 0;
uint32_t lastButtonEdge = 0;
bool lastButtonReading = HIGH;
bool stableButtonState = HIGH;
const uint32_t BUTTON_DEBOUNCE_MS = 45;
const uint32_t RITSA_IDLE_MS = 20000;
bool ritsaScrolling = false;
int16_t ritsaX = -288;
uint32_t lastScrollStep = 0;
// Cintillo OLED: velocidad ajustada por pixeles por frame.
const uint32_t SCROLL_STEP_MS = 5;
const int16_t RITSA_STEP_PX = 24;
const uint8_t RITSA_TEXT_SIZE = 3;
String ritsaMessage = "RITSA ELECTRONICA";
bool ritsaEnabled = true;
Preferences prefs;

// ============================================================
//                  ONBOARD microSD / WEB STORAGE
// ============================================================
// Waveshare ESP32-S3-ETH official SDSPI wiring:
// CS=GPIO4, MISO=GPIO5, MOSI=GPIO6, SCLK=GPIO7
#define SD_CS   4
#define SD_MISO 5
#define SD_MOSI 6
#define SD_SCLK 7
SPIClass sdSPI(FSPI);
bool sdOK = false;
volatile bool sdUploadBusy = false;
File sdUploadFile;

static bool initSDCard();
static bool serveSDFile(const String &path);
static String contentTypeFor(const String &path);

// ============================================================
//                       MINER VARIABLES
// ============================================================

WiFiClient pool;
WebServer webServer(80);
DNSServer dnsServer;
bool webStarted = false;
TaskHandle_t webTaskHandle = NULL;
volatile uint32_t webRequestCount = 0;
volatile uint32_t webStatsCount = 0;

bool wifiSetupMode = false;
bool dnsStarted = false;
String savedWifiSsid;
String savedWifiPassword;
volatile bool wifiRestartPending = false;
uint32_t wifiRestartAt = 0;
static const char* SETUP_AP_SSID = "RITSA-MINER-SETUP";
static const IPAddress SETUP_AP_IP(192,168,4,1);
static void startWebIfNeeded();

String rxLine;
String extranonce1 = "";

uint8_t extranonce2Size = 4;

double poolDifficulty = 98.304;

uint32_t lastConnectAttempt = 0;
uint32_t nextSubmitId = 10;

volatile uint64_t totalHashes = 0;
volatile uint64_t accepted = 0;
volatile uint64_t rejected = 0;
volatile uint32_t lastAcceptedShareMs = 0;

volatile float currentHashrate = 0.0;

uint32_t reportMs = 0;
uint64_t reportHashes = 0;

// ============================================================
//                   PERFORMANCE SETTINGS
// ============================================================

// Antes: 4 hashes por ciclo.
//
// Ahora procesamos un lote bastante mayor antes de atender
// tareas secundarias.
//
// No lo hagas enorme todavía. Primero buscamos estabilidad.

#define HASH_BATCH_SIZE 32

// Revisamos el pool periódicamente dentro del lote.
// Esto evita readPool() después de CADA hash.

#define POOL_CHECK_INTERVAL 8

// Actualización OLED
#define OLED_UPDATE_MS 5000

// Animación TFT
#define TFT_UPDATE_MS 10000

uint32_t lastOLEDUpdate = 0;
uint32_t lastTFTUpdate = 0;

uint8_t pepeFrame = 0;

// ============================================================
//                           JOB
// ============================================================

struct Job {

  String id;
  String prev;
  String coinb1;
  String coinb2;
  String version;
  String nbits;
  String ntime;

  String branches[16];

  int branchCount = 0;

  bool valid = false;

  uint32_t nonce = 0;
  uint32_t extra2 = 0;
};

Job job;

// ============================================================
//              V3 PERFORMANCE - DUAL CORE HOOHASH
// ============================================================
// Core 1 mantiene Wi-Fi/Stratum y mina nonces pares.
// Core 0 mina nonces impares. La pantalla TFT queda estatica y
// la OLED se actualiza con baja frecuencia para dejar CPU al hash.

portMUX_TYPE workMux = portMUX_INITIALIZER_UNLOCKED;
volatile uint32_t workGeneration = 0;
uint8_t sharedHeader[80] = {0};
uint8_t sharedTarget[32] = {0};
volatile uint64_t core0Hashes = 0;
volatile uint64_t core1Hashes = 0;

struct FoundShare {
  uint32_t generation;
  uint32_t nonce;
};

QueueHandle_t foundQueue = nullptr;


// ============================================================
//                       HEX UTILITIES
// ============================================================

static int hv(char c) {

  if(c >= '0' && c <= '9')
    return c - '0';

  if(c >= 'a' && c <= 'f')
    return c - 'a' + 10;

  if(c >= 'A' && c <= 'F')
    return c - 'A' + 10;

  return -1;
}

static bool hexToBytes(
  const String &s,
  uint8_t *out,
  size_t n
) {

  if(s.length() != n * 2)
    return false;

  for(size_t i = 0; i < n; i++) {

    int a = hv(s[i * 2]);
    int b = hv(s[i * 2 + 1]);

    if(a < 0 || b < 0)
      return false;

    out[i] = (a << 4) | b;
  }

  return true;
}

static String hex8(uint32_t v) {

  char b[9];

  snprintf(
    b,
    sizeof(b),
    "%08lx",
    (unsigned long)v
  );

  return String(b);
}

static void reverseBytes(
  const uint8_t *in,
  uint8_t *out,
  size_t n
) {

  for(size_t i = 0; i < n; i++)
    out[i] = in[n - 1 - i];
}

static void reverseWords4(
  const uint8_t *in,
  uint8_t *out
) {

  for(int w = 0; w < 8; w++)
    memcpy(
      out + w * 4,
      in + (7 - w) * 4,
      4
    );
}

// ============================================================
//                          SHA256D
// ============================================================

static void sha256d(
  const uint8_t *d,
  size_t n,
  uint8_t out[32]
) {

  uint8_t t[32];

  mbedtls_sha256(
    d,
    n,
    t,
    0
  );

  mbedtls_sha256(
    t,
    32,
    out,
    0
  );
}

static void printHex(
  const uint8_t *p,
  size_t n
) {

  for(size_t i = 0; i < n; i++)
    Serial.printf("%02X", p[i]);

  Serial.println();
}

// ============================================================
//                         TARGET
// ============================================================

static void makeTarget(
  double diff,
  uint8_t target[32]
) {

  memset(target, 0, 32);

  if(diff <= 0)
    diff = 1;

  uint64_t divisor =
    (uint64_t)llround(diff * 1000000.0);

  uint8_t src[32] = {0};

  src[0] = 0x00;
  src[1] = 0x00;
  src[2] = 0xff;
  src[3] = 0xff;

  uint8_t scaled[36] = {0};

  uint64_t carry = 0;

  for(int i = 31; i >= 0; i--) {

    uint64_t v =
      (uint64_t)src[i] * 1000000ULL + carry;

    scaled[i + 4] =
      (uint8_t)(v & 0xff);

    carry = v >> 8;
  }

  for(int i = 3; i >= 0 && carry; i--) {

    scaled[i] =
      (uint8_t)(carry & 0xff);

    carry >>= 8;
  }

  uint64_t rem = 0;

  uint8_t q[36] = {0};

  for(int i = 0; i < 36; i++) {

    rem =
      (rem << 8) | scaled[i];

    q[i] =
      (uint8_t)(rem / divisor);

    rem %= divisor;
  }

  memcpy(
    target,
    q + 4,
    32
  );
}

static bool hashMeets(
  const uint8_t hash[32],
  const uint8_t target[32]
) {

  for(int i = 0; i < 32; i++) {

    if(hash[i] < target[i])
      return true;

    if(hash[i] > target[i])
      return false;
  }

  return true;
}

// ============================================================
//                  PEPEW VALIDATION VECTOR
// ============================================================

static bool validatePepew() {

  const char* hh =
    "0040002038e31388c54124146478ff691985eecd02610db91efbc9cd7aabca490000000007647f0508057dbf8c99ddaa87543c04e31dfe3f383e7386903d50c91728fabe830be16971e3021da96d9d33";

  const char* eh =
    "00000001fb895a82973fca52938848908d6a6cb3c0dfb93995dc61020ced0a6b";

  uint8_t h[80];
  uint8_t o[32];
  uint8_t e[32];

  hexToBytes(
    String(hh),
    h,
    80
  );

  hexToBytes(
    String(eh),
    e,
    32
  );

  hoohashv110(
    h,
    80,
    o
  );

  Serial.print("Expected : ");
  printHex(e, 32);

  Serial.print("ESP32    : ");
  printHex(o, 32);

  bool ok =
    memcmp(o, e, 32) == 0;

  Serial.printf(
    "PEPEW VECTOR: %s\n",
    ok ? "PASS" : "FAIL"
  );

  return ok;
}

// ============================================================
//                       STRATUM PARSER
// ============================================================

static String jsonStringAt(
  const String &s,
  int &p
) {

  while(
    p < (int)s.length() &&
    s[p] != '"'
  )
    p++;

  if(p >= s.length())
    return "";

  int a = ++p;

  while(
    p < (int)s.length() &&
    s[p] != '"'
  )
    p++;

  String r =
    s.substring(a, p);

  p++;

  return r;
}

// ============================================================
//                         NEW JOB
// ============================================================

static bool parseNotify(
  const String &line
) {

  int p =
    line.indexOf("\"params\":[");

  if(p < 0)
    return false;

  p += 10;

  Job n;

  n.id =
    jsonStringAt(line, p);

  n.prev =
    jsonStringAt(line, p);

  n.coinb1 =
    jsonStringAt(line, p);

  n.coinb2 =
    jsonStringAt(line, p);

  int arr =
    line.indexOf('[', p);

  int end =
    line.indexOf(']', arr);

  if(arr < 0 || end < 0)
    return false;

  int bp =
    arr + 1;

  while(
    bp < end &&
    n.branchCount < 16
  ) {

    int q =
      line.indexOf('"', bp);

    if(q < 0 || q >= end)
      break;

    bp = q;

    n.branches[n.branchCount++] =
      jsonStringAt(line, bp);
  }

  p = end + 1;

  n.version =
    jsonStringAt(line, p);

  n.nbits =
    jsonStringAt(line, p);

  n.ntime =
    jsonStringAt(line, p);

  n.valid = true;

  n.nonce = 0;

  n.extra2++;

  job = n;

  Serial.printf(
    "[JOB] %s branches=%d diff=%.6f\n",
    job.id.c_str(),
    job.branchCount,
    poolDifficulty
  );

  return true;
}

// ============================================================
//                     BUILD BLOCK HEADER
// ============================================================

static bool buildHeader(
  uint8_t header[80],
  String &extra2hex
) {

  if(
    !job.valid ||
    extranonce1.length() == 0
  )
    return false;

  extra2hex =
    hex8(job.extra2);

  String cbhex =
    job.coinb1 +
    extranonce1 +
    extra2hex +
    job.coinb2;

  size_t cblen =
    cbhex.length() / 2;

  uint8_t *cb =
    (uint8_t*)malloc(cblen);

  if(!cb)
    return false;

  if(
    !hexToBytes(
      cbhex,
      cb,
      cblen
    )
  ) {

    free(cb);
    return false;
  }

  uint8_t merkle[32];

  sha256d(
    cb,
    cblen,
    merkle
  );

  free(cb);

  for(
    int i = 0;
    i < job.branchCount;
    i++
  ) {

    uint8_t br[32];
    uint8_t buf[64];
    uint8_t tmp[32];

    if(
      !hexToBytes(
        job.branches[i],
        br,
        32
      )
    )
      return false;

    memcpy(
      buf,
      merkle,
      32
    );

    memcpy(
      buf + 32,
      br,
      32
    );

    sha256d(
      buf,
      64,
      tmp
    );

    memcpy(
      merkle,
      tmp,
      32
    );
  }

  uint8_t v[4];
  uint8_t phw[32];
  uint8_t ph[32];
  uint8_t tm[4];
  uint8_t bits[4];

  if(
    !hexToBytes(job.version, v, 4) ||
    !hexToBytes(job.prev, phw, 32) ||
    !hexToBytes(job.ntime, tm, 4) ||
    !hexToBytes(job.nbits, bits, 4)
  )
    return false;

  reverseBytes(
    v,
    header,
    4
  );

  reverseWords4(
    phw,
    ph
  );

  memcpy(
    header + 4,
    ph,
    32
  );

  memcpy(
    header + 36,
    merkle,
    32
  );

  reverseBytes(
    tm,
    header + 68,
    4
  );

  reverseBytes(
    bits,
    header + 72,
    4
  );

  return true;
}

// ============================================================
//                          NONCE
// ============================================================

static inline void putNonce(
  uint8_t *h,
  uint32_t n
) {

  h[76] = n & 255;
  h[77] = (n >> 8) & 255;
  h[78] = (n >> 16) & 255;
  h[79] = (n >> 24) & 255;
}

// ============================================================
//                          STRATUM
// ============================================================

static void sendLine(
  const String &s
) {

  if(pool.connected()) {

    pool.print(s);
    pool.print('\n');
  }
}

static void submitShare(
  uint32_t nonce,
  const String &extra2
) {

  String user =
    String(WALLET) +
    "." +
    WORKER;

  String req =
    String("{\"id\":") +
    (nextSubmitId++) +
    ",\"method\":\"mining.submit\",\"params\":[\"" +
    user +
    "\",\"" +
    job.id +
    "\",\"" +
    extra2 +
    "\",\"" +
    job.ntime +
    "\",\"" +
    hex8(nonce) +
    "\"]}";

  Serial.print(
    "[SHARE] SUBMIT nonce="
  );

  Serial.println(
    hex8(nonce)
  );

  sendLine(req);
}

// ============================================================
//                      HANDLE POOL DATA
// ============================================================

static void handleLine(
  const String &line
) {

  if(
    line.indexOf("\"id\":1") >= 0 &&
    line.indexOf("\"result\":[") >= 0
  ) {

    int q =
      line.indexOf("]],\"");

    if(q >= 0) {

      int a = q + 4;

      int b =
        line.indexOf('"', a);

      extranonce1 =
        line.substring(a, b);

      int comma =
        line.indexOf(',', b);

      int close =
        line.indexOf(']', comma);

      if(
        comma >= 0 &&
        close > comma
      ) {

        extranonce2Size =
          line.substring(
            comma + 1,
            close
          ).toInt();
      }

      Serial.printf(
        "[SUB] extranonce1=%s size=%u\n",
        extranonce1.c_str(),
        extranonce2Size
      );
    }
  }

  if(
    line.indexOf(
      "mining.set_difficulty"
    ) >= 0
  ) {

    int p =
      line.indexOf("\"params\":[");

    if(p >= 0) {

      p += 10;

      poolDifficulty =
        line.substring(
          p,
          line.indexOf(']', p)
        ).toDouble();

      Serial.printf(
        "[DIFF] %.6f\n",
        poolDifficulty
      );
    }
  }

  if(
    line.indexOf(
      "mining.notify"
    ) >= 0
  )
    parseNotify(line);

  if(
    line.indexOf("\"id\":2") >= 0 &&
    line.indexOf("true") >= 0
  )
    Serial.println(
      "[AUTH] ACCEPTED"
    );

  if(
    line.indexOf("\"id\":") >= 0 &&
    line.indexOf("\"result\":true") >= 0 &&
    line.indexOf("\"id\":2") < 0
  ) {

    accepted++;
    lastAcceptedShareMs = millis();

    Serial.printf(
      "[SHARE] ACCEPTED! total=%llu\n",
      accepted
    );
  }

  if(
    line.indexOf("\"id\":") >= 0 &&
    line.indexOf("\"result\":null") >= 0
  ) {

    rejected++;

    Serial.print(
      "[SHARE] REJECTED: "
    );

    Serial.println(line);
  }
}

// ============================================================
//                         READ POOL
// ============================================================

static void readPool() {

  while(
    pool.connected() &&
    pool.available()
  ) {

    char c =
      pool.read();

    if(c == '\r')
      continue;

    if(c == '\n') {

      if(rxLine.length())
        handleLine(rxLine);

      rxLine = "";

    } else if(
      rxLine.length() < 8190
    ) {

      rxLine += c;
    }
  }
}

// ============================================================
//                           WIFI
// ============================================================

static void startSetupAP() {
  if(wifiSetupMode) return;
  pool.stop();
  WiFi.disconnect(true, false);
  delay(100);
  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(SETUP_AP_IP, SETUP_AP_IP, IPAddress(255,255,255,0));
  // AP abierto a proposito: solo sirve para configurar la red local del minero.
  WiFi.softAP(SETUP_AP_SSID);
  wifiSetupMode = true;
  dnsServer.start(53, "*", SETUP_AP_IP);
  dnsStarted = true;
  Serial.printf("[WIFI-SETUP] AP: %s | http://192.168.4.1/\\n", SETUP_AP_SSID);
}

static bool connectSavedWiFi(uint32_t timeoutMs=15000) {
  savedWifiSsid = prefs.getString("wifiSsid", "");
  savedWifiPassword = prefs.getString("wifiPass", "");
  if(savedWifiSsid.length()==0) return false;

  wifiSetupMode = false;
  if(dnsStarted) { dnsServer.stop(); dnsStarted=false; }
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(savedWifiSsid.c_str(), savedWifiPassword.c_str());
  Serial.printf("[WIFI] Connecting to saved network: %s", savedWifiSsid.c_str());
  uint32_t t0=millis();
  while(WiFi.status()!=WL_CONNECTED && millis()-t0<timeoutMs) {
    vTaskDelay(pdMS_TO_TICKS(250));
    Serial.print('.');
  }
  Serial.println();
  if(WiFi.status()==WL_CONNECTED) {
    Serial.printf("[WIFI] CONNECTED %s RSSI=%d\\n", WiFi.localIP().toString().c_str(), WiFi.RSSI());
    return true;
  }
  Serial.println("[WIFI] Saved network unavailable -> SETUP AP");
  return false;
}

static void wifiConnect() {
  if(WiFi.status()==WL_CONNECTED) return;
  if(wifiSetupMode) return;
  if(!connectSavedWiFi(15000)) startSetupAP();
}

// ============================================================
//                        CONNECT POOL
// ============================================================

static void poolConnect() {

  if(
    WiFi.status() != WL_CONNECTED ||
    pool.connected() ||
    millis() - lastConnectAttempt < 5000
  )
    return;

  lastConnectAttempt =
    millis();

  Serial.printf(
    "[POOL] %s:%u ...\n",
    POOL_HOST,
    POOL_PORT
  );

  if(
    pool.connect(
      POOL_HOST,
      POOL_PORT
    )
  ) {

    Serial.println(
      "[POOL] CONNECTED"
    );

    sendLine(
      "{\"id\":1,\"method\":\"mining.subscribe\",\"params\":[\"PEPEW_ESP32S3/2.2\"]}"
    );

    delay(30);

    String u =
      String(WALLET) +
      "." +
      WORKER;

    sendLine(
      String(
        "{\"id\":2,\"method\":\"mining.authorize\",\"params\":[\""
      ) +
      u +
      "\",\"x\"]}"
    );
  }
}

// ============================================================
//                      TFT - PEPE MINER
// ============================================================

#if 0  // DIBUJO ANTIGUO CONSERVADO SOLO COMO REFERENCIA
void drawPepeMiner(uint8_t frame) {

  // Fondo
  tft.fillScreen(
    GC9A01A_BLACK
  );

  // Borde circular
  tft.drawCircle(
    120,
    120,
    118,
    GC9A01A_CYAN
  );

  // -----------------------
  // Casco
  // -----------------------

  tft.fillCircle(
    120,
    78,
    47,
    GC9A01A_YELLOW
  );

  tft.fillRect(
    73,
    76,
    94,
    18,
    GC9A01A_YELLOW
  );

  // -----------------------
  // Cabeza PEPE
  // -----------------------

  tft.fillCircle(
    120,
    118,
    46,
    GC9A01A_GREEN
  );

  // ojos
  tft.fillCircle(
    101,
    105,
    13,
    GC9A01A_WHITE
  );

  tft.fillCircle(
    139,
    105,
    13,
    GC9A01A_WHITE
  );

  tft.fillCircle(
    104,
    108,
    5,
    GC9A01A_BLACK
  );

  tft.fillCircle(
    136,
    108,
    5,
    GC9A01A_BLACK
  );

  // Cara triste
  tft.drawLine(
    97,
    143,
    120,
    135,
    GC9A01A_BLACK
  );

  tft.drawLine(
    120,
    135,
    144,
    143,
    GC9A01A_BLACK
  );

  // lágrima
  tft.fillCircle(
    145,
    124,
    4,
    GC9A01A_CYAN
  );

  // -----------------------
  // Pico animado
  // -----------------------

  int offset =
    (frame % 2) ? 7 : 0;

  tft.drawLine(
    55,
    150 + offset,
    83,
    170,
    GC9A01A_WHITE
  );

  tft.drawLine(
    55,
    150 + offset,
    42,
    137 + offset,
    GC9A01A_WHITE
  );

  // -----------------------
  // Texto
  // -----------------------

  tft.setTextColor(
    GC9A01A_WHITE
  );

  tft.setTextSize(1);

  tft.setCursor(
    77,
    185
  );

  tft.print(
    "PEPEW MINER"
  );

  tft.setTextColor(
    GC9A01A_GREEN
  );

  tft.setCursor(
    82,
    201
  );

  tft.printf(
    "%.1f H/s",
    currentHashrate
  );
}

#endif

void drawPepeMiner(uint8_t frame) {

  // Nueva imagen RGB565 240x240 de Pepe minando.
  // Se dibuja una sola vez para no quitar tiempo al minero.
  static bool imageDrawn = false;
  (void)frame;

  if(imageDrawn)
    return;

  tft.fillScreen(
    GC9A01A_BLACK
  );

  tft.drawRGBBitmap(
    0,
    0,
    pepe_miner_240,
    PEPE_MINER_W,
    PEPE_MINER_H
  );

  imageDrawn = true;
}


void updateOLED();

// ============================================================
//                       WEB DASHBOARD
// ============================================================

static String lastShareText() {
  uint32_t t = lastAcceptedShareMs;
  if(t == 0) return "Never";
  uint32_t sec = (millis() - t) / 1000UL;
  if(sec < 60) return String(sec) + " sec ago";
  if(sec < 3600) return String(sec / 60) + " min ago";
  return String(sec / 3600) + " h ago";
}

static String jsonEscape(const String &in) {
  String out;
  out.reserve(in.length() + 8);
  for(size_t i=0;i<in.length();i++) {
    char c=in[i];
    if(c=='\\' || c=='\"') { out += '\\'; out += c; }
    else if(c=='\n') out += "\\n";
    else if(c=='\r') out += "\\r";
    else out += c;
  }
  return out;
}

static void handleApiStats() {
  webStatsCount++;
  String json = "{";
  json += "\"hashrate\":" + String(currentHashrate, 2);
  json += ",\"totalHashes\":" + String((unsigned long long)totalHashes);
  json += ",\"accepted\":" + String((unsigned long long)accepted);
  json += ",\"rejected\":" + String((unsigned long long)rejected);
  json += ",\"difficulty\":" + String(poolDifficulty, 3);
  json += ",\"pool\":" + String(pool.connected() ? "true" : "false");
  json += ",\"wifiRssi\":" + String(WiFi.RSSI());
  json += ",\"uptime\":" + String(millis()/1000UL);
  json += ",\"lastShare\":\"" + lastShareText() + "\"";
  json += ",\"oledPage\":" + String((unsigned)oledPage);
  json += ",\"tickerEnabled\":" + String(ritsaEnabled ? "true" : "false");
  json += ",\"tickerMessage\":\"" + jsonEscape(ritsaMessage) + "\"";
  json += "}";
  webServer.send(200, "application/json", json);
}

static void handleTickerSave() {
  if(webServer.hasArg("message")) {
    String m = webServer.arg("message");
    m.trim();
    if(m.length() > 40) m = m.substring(0,40);
    if(m.length() > 0) ritsaMessage = m;
  }
  if(webServer.hasArg("enabled")) {
    String e=webServer.arg("enabled"); e.toLowerCase();
    ritsaEnabled = (e=="1" || e=="true" || e=="on" || e=="yes");
  }
  prefs.putString("tickerMsg", ritsaMessage);
  prefs.putBool("tickerOn", ritsaEnabled);
  // Solo cambiamos estado. El displayTask dibuja despues.
  ritsaScrolling=false;
  lastButtonActivity=millis();
  lastOLEDUpdate=0;
  oledNeedsRefresh=true;
  webServer.send(200,"application/json","{\"ok\":true}");
  Serial.printf("[WEB] Ticker: %s | %s\\n", ritsaEnabled?"ON":"OFF", ritsaMessage.c_str());
}

static int16_t ritsaTextWidth();  // forward declaration

static void setOledPageFromControl(uint8_t page) {
  if(page > 3) page = 0;

  // IMPORTANTE V6.6: aqui NO dibujamos nada por I2C.
  // Solo cambiamos estado y regresamos inmediatamente.
  ritsaScrolling = false;
  oledPage = (OledPage)page;
  lastButtonActivity = millis();
  ritsaX = -ritsaTextWidth();
  lastOLEDUpdate = 0;
  oledNeedsRefresh = true;

  Serial.printf("[OLED] PAGE REQUEST = %u\n", (unsigned)oledPage);
}

static void handleOledPage() {
  if(!webServer.hasArg("page")) {
    webServer.send(400, "application/json", "{\\\"ok\\\":false}");
    return;
  }
  int p = webServer.arg("page").toInt();
  if(p < 0 || p > 3) {
    webServer.send(400, "application/json", "{\\\"ok\\\":false}");
    return;
  }
  setOledPageFromControl((uint8_t)p);
  webServer.send(200, "application/json", "{\\\"ok\\\":true}");
}

static String htmlEscape(const String &in) {
  String o; o.reserve(in.length()+8);
  for(size_t i=0;i<in.length();++i){ char c=in[i]; if(c=='&')o+="&amp;"; else if(c=='<')o+="&lt;"; else if(c=='>')o+="&gt;"; else if(c=='\"')o+="&quot;"; else o+=c; }
  return o;
}

static String contentTypeFor(const String &path) {
  if(path.endsWith(".html")) return "text/html; charset=utf-8";
  if(path.endsWith(".css"))  return "text/css; charset=utf-8";
  if(path.endsWith(".js"))   return "application/javascript; charset=utf-8";
  if(path.endsWith(".json")) return "application/json; charset=utf-8";
  if(path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
  if(path.endsWith(".png"))  return "image/png";
  if(path.endsWith(".svg"))  return "image/svg+xml";
  if(path.endsWith(".ico"))  return "image/x-icon";
  if(path.endsWith(".txt"))  return "text/plain; charset=utf-8";
  return "application/octet-stream";
}

static bool serveSDFile(const String &path) {
  if(!sdOK) return false;
  webRequestCount++;
  String p=path;
  if(!p.startsWith("/")) p="/"+p;
  File f=SD.open(p, FILE_READ);
  if(!f || f.isDirectory()) { if(f) f.close(); return false; }
  if(p.endsWith(".jpg") || p.endsWith(".png") || p.endsWith(".css") || p.endsWith(".js"))
    webServer.sendHeader("Cache-Control","public, max-age=86400");
  else
    webServer.sendHeader("Cache-Control","no-store");
  webServer.streamFile(f, contentTypeFor(p));
  f.close();
  return true;
}

static void handleWifiPage() {
  if(serveSDFile("/www/wifi.html")) return;
  // Portal de emergencia: funciona aun sin microSD.
  String page=F(R"HTML(<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>RITSA WiFi Setup</title><style>body{margin:0;background:#061b22;color:#f7f1df;font-family:Arial;padding:22px}.c{max-width:560px;margin:auto;background:#0b2a32;border:1px solid #17515a;border-radius:18px;padding:22px}h1{color:#ffc928}select,input,button{box-sizing:border-box;width:100%;padding:14px;margin:7px 0;border-radius:10px;font-size:16px}select,input{background:#061b22;color:#fff;border:1px solid #27717a}button{background:#ffc928;border:0;font-weight:800}.m{color:#61e294}</style></head><body><div class="c"><h1>RITSA ELECTRONICA</h1><p>WiFi Setup - modo de emergencia</p><p><b>AP:</b> RITSA-MINER-SETUP<br><b>IP:</b> 192.168.4.1</p><select id="n"><option>Buscando redes...</option></select><input id="s" placeholder="SSID"><input id="p" type="password" placeholder="Password"><button id="b">GUARDAR Y CONECTAR</button><div id="m" class="m"></div></div><script>
const n=document.getElementById('n'),s=document.getElementById('s'),p=document.getElementById('p'),m=document.getElementById('m');
fetch('/api/wifi/scan').then(r=>r.json()).then(j=>{n.innerHTML='<option value="">Seleccionar red...</option>';j.networks.forEach(x=>{let o=document.createElement('option');o.value=x.ssid;o.textContent=x.ssid+' ('+x.rssi+' dBm)';n.appendChild(o)});n.onchange=()=>{if(n.value)s.value=n.value}});
document.getElementById('b').onclick=()=>{let q=new URLSearchParams({ssid:s.value,password:p.value});fetch('/api/wifi/save',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:q}).then(()=>m.textContent='Guardado. Reiniciando...')};
</script></body></html>)HTML");
  webServer.send(200,"text/html; charset=utf-8",page);
}

static void handleWifiScan() {
  int n=WiFi.scanNetworks(false,true);
  String j="{\\\"networks\\\":[";
  for(int i=0;i<n;i++) { if(i)j+=','; j+="{\\\"ssid\\\":\\\""+jsonEscape(WiFi.SSID(i))+"\\\",\\\"rssi\\\":"+String(WiFi.RSSI(i))+"}"; }
  j+="]}";
  WiFi.scanDelete();
  webServer.send(200,"application/json",j);
}

static void handleWifiSave() {
  if(!webServer.hasArg("ssid")) { webServer.send(400,"application/json","{\\\"ok\\\":false}"); return; }
  String ssid=webServer.arg("ssid"); String pass=webServer.arg("password"); ssid.trim();
  if(ssid.length()==0 || ssid.length()>32 || pass.length()>64) { webServer.send(400,"application/json","{\\\"ok\\\":false}"); return; }
  prefs.putString("wifiSsid",ssid); prefs.putString("wifiPass",pass);
  savedWifiSsid=ssid; savedWifiPassword=pass;
  webServer.send(200,"application/json","{\\\"ok\\\":true,\\\"restart\\\":true}");
  wifiRestartPending=true; wifiRestartAt=millis()+1500;
}

static void handleWifiClear() {
  prefs.remove("wifiSsid"); prefs.remove("wifiPass"); savedWifiSsid=""; savedWifiPassword="";
  webServer.send(200,"application/json","{\\\"ok\\\":true,\\\"restart\\\":true}");
  wifiRestartPending=true; wifiRestartAt=millis()+1200;
}

static void handleWebRoot() {
  if(serveSDFile("/www/index.html")) return;
  String h=F("<!doctype html><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{font-family:Arial;background:#061b22;color:white;padding:24px}a{color:#ffc928}</style><h1>RITSA MINER</h1><p>microSD no disponible o falta <b>/www/index.html</b>.</p><p>La mineria puede continuar.</p><p><a href='/wifi'>Configurar WiFi</a></p>");
  webServer.send(503,"text/html; charset=utf-8",h);
}

static void handleSDStatus() {
  String j="{";
  j += "\"mounted\":" + String(sdOK?"true":"false");
  if(sdOK) {
    j += ",\"total\":" + String((uint64_t)SD.totalBytes());
    j += ",\"used\":" + String((uint64_t)SD.usedBytes());
  }
  j += "}";
  webServer.send(200,"application/json",j);
}

static void appendDirJson(File dir, String &j, const String &base, int depth) {
  if(depth>4) return;
  File f=dir.openNextFile();
  bool first=true;
  while(f) {
    if(!first) j += ",";
    first=false;
    String name=String(f.name());
    j += "{\"name\":\"" + name + "\",\"dir\":" + String(f.isDirectory()?"true":"false");
    if(!f.isDirectory()) j += ",\"size\":" + String((uint64_t)f.size());
    j += "}";
    f=dir.openNextFile();
  }
}

static void handleSDList() {
  if(!sdOK){ webServer.send(503,"application/json","{\"ok\":false,\"error\":\"SD not mounted\"}"); return; }
  File d=SD.open("/");
  String j="{\"ok\":true,\"files\":[";
  appendDirJson(d,j,"/",0);
  j += "]}";
  d.close();
  webServer.send(200,"application/json",j);
}

static void handleSDDelete() {
  if(!sdOK || !webServer.hasArg("path")){ webServer.send(400,"application/json","{\"ok\":false}"); return; }
  String p=webServer.arg("path");
  if(!p.startsWith("/") || p=="/"){ webServer.send(400,"application/json","{\"ok\":false}"); return; }
  bool ok=SD.remove(p);
  webServer.send(ok?200:500,"application/json",ok?"{\"ok\":true}":"{\"ok\":false}");
}

static void handleSDUploadData() {
  HTTPUpload &up=webServer.upload();
  if(!sdOK) return;
  if(up.status==UPLOAD_FILE_START) {
    String filename=up.filename;
    if(!filename.startsWith("/")) filename="/"+filename;
    // El navegador envia rutas relativas como www/index.html.
    int slash=filename.lastIndexOf('/');
    if(slash>0) {
      String dir=filename.substring(0,slash);
      SD.mkdir(dir);
    }
    if(SD.exists(filename)) SD.remove(filename);
    sdUploadFile=SD.open(filename,FILE_WRITE);
    sdUploadBusy=true;
  } else if(up.status==UPLOAD_FILE_WRITE) {
    if(sdUploadFile) sdUploadFile.write(up.buf,up.currentSize);
  } else if(up.status==UPLOAD_FILE_END || up.status==UPLOAD_FILE_ABORTED) {
    if(sdUploadFile) sdUploadFile.close();
    sdUploadBusy=false;
  }
}

static void handleSDUploadDone() {
  if(!sdOK){ webServer.send(503,"application/json","{\"ok\":false,\"error\":\"SD not mounted\"}"); return; }
  webServer.send(200,"application/json","{\"ok\":true}");
}

static void setupWebRoutes() {
  webServer.on("/", HTTP_GET, [](){ if(wifiSetupMode) handleWifiPage(); else handleWebRoot(); });
  webServer.on("/wifi", HTTP_GET, handleWifiPage);
  webServer.on("/files", HTTP_GET, [](){ if(!serveSDFile("/www/files.html")) webServer.send(404,"text/plain","/www/files.html missing"); });
  webServer.on("/style.css", HTTP_GET, [](){ if(!serveSDFile("/www/style.css")) webServer.send(404,"text/plain","missing"); });
  webServer.on("/app.js", HTTP_GET, [](){ if(!serveSDFile("/www/app.js")) webServer.send(404,"text/plain","missing"); });
  webServer.on("/ritsa.jpg", HTTP_GET, [](){ if(!serveSDFile("/www/ritsa.jpg")) webServer.send(404,"text/plain","missing"); });

  webServer.on("/api/wifi/scan", HTTP_GET, handleWifiScan);
  webServer.on("/api/wifi/save", HTTP_POST, handleWifiSave);
  webServer.on("/api/wifi/clear", HTTP_POST, handleWifiClear);
  webServer.on("/api/stats", HTTP_GET, handleApiStats);
  webServer.on("/api/ticker", HTTP_POST, handleTickerSave);
  webServer.on("/api/oled-page", HTTP_POST, handleOledPage);

  webServer.on("/api/sd/status", HTTP_GET, handleSDStatus);
  webServer.on("/api/sd/list", HTTP_GET, handleSDList);
  webServer.on("/api/sd/delete", HTTP_POST, handleSDDelete);
  webServer.on("/api/sd/upload", HTTP_POST, handleSDUploadDone, handleSDUploadData);

  webServer.onNotFound([](){
    if(wifiSetupMode){ webServer.sendHeader("Location","http://192.168.4.1/",true); webServer.send(302,"text/plain",""); return; }
    String p=webServer.uri();
    if(p.startsWith("/www/") && serveSDFile(p)) return;
    webServer.send(404,"text/plain","Not found");
  });
}

static void startWebIfNeeded() {
  if(webStarted) return;
  webServer.begin(); webStarted=true;
  if(wifiSetupMode) Serial.println("[WEB] WiFi setup READY: http://192.168.4.1/");
  else if(WiFi.status()==WL_CONNECTED) Serial.printf("[WEB] Dashboard READY: http://%s/\\n", WiFi.localIP().toString().c_str());
}

// ============================================================
//                     OLED DASHBOARD
// ============================================================

static void oledMain() {
  oled.setTextSize(2); oled.setCursor(0,0); oled.printf("%.1f", currentHashrate);
  oled.setTextSize(1); oled.print(" H/s"); oled.drawLine(0,18,127,18,SSD1306_WHITE);
  oled.setCursor(0,23); oled.print("HASH ");
  if(totalHashes>=1000000ULL) oled.printf("%.2fM",(double)totalHashes/1000000.0);
  else if(totalHashes>=1000ULL) oled.printf("%.1fK",(double)totalHashes/1000.0);
  else oled.printf("%llu",(unsigned long long)totalHashes);
  oled.setCursor(0,36); oled.printf("A/R  %llu/%llu",(unsigned long long)accepted,(unsigned long long)rejected);

  // La IP queda siempre visible para poder administrar/vender el minero
  // sin necesitar Arduino IDE ni Monitor Serial.
  oled.setCursor(0,49);
  if(wifiSetupMode) {
    oled.print("IP 192.168.4.1");
  } else if(WiFi.status()==WL_CONNECTED) {
    oled.print("IP ");
    oled.print(WiFi.localIP());
  } else {
    oled.print("WIFI CONNECTING");
  }
}

static void oledHashrate() {
  oled.setTextSize(1); oled.setCursor(34,0); oled.print("HASHRATE");
  oled.setTextSize(3); char b[16]; snprintf(b,sizeof(b),"%.1f",currentHashrate);
  int16_t x1,y1; uint16_t w,h; oled.getTextBounds(b,0,0,&x1,&y1,&w,&h); oled.setCursor((128-w)/2,20); oled.print(b);
  oled.setTextSize(1); oled.setCursor(52,53); oled.print("H/s");
}

static void oledTotal() {
  oled.setTextSize(1); oled.setCursor(28,2); oled.print("TOTAL HASHES");
  char b[24]; snprintf(b,sizeof(b),"%llu",(unsigned long long)totalHashes);
  oled.setTextSize(strlen(b)<=8?2:1); int16_t x1,y1; uint16_t w,h; oled.getTextBounds(b,0,0,&x1,&y1,&w,&h); oled.setCursor((128-w)/2,27); oled.print(b);
  oled.setTextSize(1); oled.setCursor(24,54); oled.print("SINCE START");
}

static void oledShares() {
  oled.setTextSize(1); oled.setCursor(0,0); oled.print("LAST SHARE");
  String ls=lastShareText(); oled.setTextSize(2); oled.setCursor(0,13); oled.print(ls);
  oled.drawLine(0,34,127,34,SSD1306_WHITE); oled.setTextSize(1); oled.setCursor(0,39); oled.print("ACCEPTED SHARES");
  oled.setTextSize(2); oled.setCursor(0,50); oled.printf("%llu",(unsigned long long)accepted);
}

static int16_t ritsaTextWidth() {
  // Fuente clasica Adafruit: 6 px por caracter * escala X.
  return (int16_t)(ritsaMessage.length() * 6 * RITSA_TEXT_SIZE);
}

static void stopRitsaScroll(uint32_t now, bool redrawDashboard) {
  ritsaScrolling = false;
  ritsaX = -ritsaTextWidth();
  lastButtonActivity = now;
  oled.setTextWrap(true);
  if(redrawDashboard) oledNeedsRefresh = true;
}

static void drawRitsaScroll(uint32_t now) {
  if(now - lastScrollStep < SCROLL_STEP_MS) return;
  lastScrollStep = now;

  // CINTILLO REAL: Y nunca cambia. No hay wrap vertical.
  // Cada frame se borra por completo antes de dibujar el siguiente.
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextWrap(false);
  oled.setTextSize(RITSA_TEXT_SIZE);

  // TextSize 3 = 24 px de alto. Centrado verticalmente.
  const int16_t y = (SCREEN_HEIGHT - (8 * RITSA_TEXT_SIZE)) / 2;
  oled.setCursor(ritsaX, y);
  oled.print(ritsaMessage);
  oled.display();

  // SOLO cambia X: izquierda -> derecha.
  ritsaX += RITSA_STEP_PX;

  // Cuando el borde izquierdo del texto ya salio por la derecha,
  // la frase completa desaparecio de la OLED.
  if(ritsaX > SCREEN_WIDTH) {
    stopRitsaScroll(now, true);
  }
}

void updateOLED() {
  if(!oledOK || ritsaScrolling) return;
  oled.clearDisplay(); oled.setTextColor(SSD1306_WHITE); oled.setTextWrap(true);
  switch(oledPage){case OLED_HASHRATE: oledHashrate(); break; case OLED_TOTAL: oledTotal(); break; case OLED_SHARES: oledShares(); break; default: oledMain(); break;}
  oled.display();
}

static void serviceButton(uint32_t now) {
  // GPIO48 -> pulsador -> GND, usando INPUT_PULLUP.
  // V6.6: esta funcion corre en una tarea dedicada de prioridad alta,
  // y JAMAS llama oled.display() ni funciones I2C.
  bool reading = digitalRead(BUTTON_PIN);

  if(reading != lastButtonReading) {
    lastButtonEdge = now;
    lastButtonReading = reading;
  }

  if((now - lastButtonEdge) >= BUTTON_DEBOUNCE_MS &&
     reading != stableButtonState) {
    stableButtonState = reading;

    if(stableButtonState == LOW) {
      uint8_t nextPage = ((uint8_t)oledPage + 1) % 4;
      setOledPageFromControl(nextPage);
      Serial.printf("[BUTTON] GPIO48 -> OLED PAGE %u\n", (unsigned)nextPage);
    }
  }
}

void buttonTask(void *pv) {
  Serial.printf("[BUTTON] Dedicated task START | core=%d\n", xPortGetCoreID());
  for(;;) {
    serviceButton(millis());
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}

// ============================================================
//                       DISPLAY TASK
// ============================================================
void displayTask(void *pv) {
  lastButtonActivity=millis();
  for(;;) {
    uint32_t now=millis();

    // Mensaje automatico solo desde MAIN y solo cuando esta habilitado.
    if(oledOK && ritsaEnabled && oledPage==OLED_MAIN &&
       !ritsaScrolling && now-lastButtonActivity>=RITSA_IDLE_MS) {
      ritsaScrolling=true;
      ritsaX=-ritsaTextWidth();
      lastScrollStep=0;
    }

    // SOLO displayTask toca el OLED. Boton y web unicamente cambian flags.
    if(ritsaScrolling) {
      drawRitsaScroll(now);
    } else if(oledNeedsRefresh || now-lastOLEDUpdate>=OLED_UPDATE_MS) {
      oledNeedsRefresh=false;
      lastOLEDUpdate=now;
      updateOLED();
    }

    // TFT queda ESTATICO. Ya se dibujo una vez en setup().
    // No se vuelve a transferir la imagen mientras el minero trabaja.

    if(dnsStarted) dnsServer.processNextRequest();
    if(webStarted) webServer.handleClient();
    if(wifiRestartPending && (int32_t)(millis()-wifiRestartAt)>=0) {
      Serial.println("[WIFI] Restarting to apply network settings...");
      delay(50);
      ESP.restart();
    }

    // Suficiente para web/display; hashWorker0 conserva prioridad superior.
    vTaskDelay(pdMS_TO_TICKS(25));
  }
}


// ============================================================
//                    WEB SERVER TASK V8.2
// ============================================================
// Dedicated task: keeps HTTP responsive without putting web work
// inside the OLED/TFT task. Priority remains below mining workers.
void webTask(void *pv) {
  Serial.printf("[WEB-TASK] START | core=%d | priority=%u\n",
                xPortGetCoreID(), (unsigned)uxTaskPriorityGet(NULL));
  uint32_t lastDiag=0;
  for(;;) {
    if(webStarted) {
      webServer.handleClient();
    }
    uint32_t now=millis();
    if(now-lastDiag>=30000UL) {
      lastDiag=now;
      Serial.printf("[WEB-DIAG] requests=%lu stats=%lu free=%uKB min=%uKB largest=%uKB\n",
        (unsigned long)webRequestCount,
        (unsigned long)webStatsCount,
        ESP.getFreeHeap()/1024,
        ESP.getMinFreeHeap()/1024,
        heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)/1024);
    }
    vTaskDelay(pdMS_TO_TICKS(8));
  }
}

// ============================================================
//                       MINER TASK
// ============================================================

static void hashWorker0(void *pv) {

  Serial.printf(
    "[CORE0] Hash worker START | core=%d | stack=%uB\n",
    xPortGetCoreID(),
    (unsigned)(uxTaskGetStackHighWaterMark(NULL) * sizeof(StackType_t))
  );

  uint32_t seenGeneration = 0;
  uint32_t nonce = 1;              // Core 0 = nonces impares
  uint8_t header[80];
  uint8_t target[32];
  uint8_t hash[32];

  for(;;) {

    uint32_t generation = workGeneration;

    if(generation == 0) {
      vTaskDelay(pdMS_TO_TICKS(5));
      continue;
    }

    if(generation != seenGeneration) {
      portENTER_CRITICAL(&workMux);
      memcpy(header, sharedHeader, 80);
      memcpy(target, sharedTarget, 32);
      generation = workGeneration;
      portEXIT_CRITICAL(&workMux);

      seenGeneration = generation;
      nonce = 1;

      Serial.printf(
        "[CORE0] New work generation=%lu\n",
        (unsigned long)seenGeneration
      );
    }

    // Lote corto para reaccionar rapido a un nuevo JOB.
    for(int i = 0; i < 16; i++) {

      if(workGeneration != seenGeneration)
        break;

      putNonce(header, nonce);
      hoohashv110_ctx(1, header, 80, hash);
      core0Hashes++;

      if(hashMeets(hash, target)) {
        FoundShare f;
        f.generation = seenGeneration;
        f.nonce = nonce;
        xQueueSend(foundQueue, &f, 0);
      }

      nonce += 2;

      // Cada 8 hashes dejamos 1 tick real al scheduler/IDLE0.
      // taskYIELD() solo cambia entre tareas listas y no garantiza
      // que IDLE0 tenga tiempo para alimentar el watchdog.
      if((i & 15) == 15)
        vTaskDelay(1);
    }

    // Segunda oportunidad para IDLE0 al terminar cada lote.
    vTaskDelay(1);
  }
}

// ============================================================
//                       MINER TASK CORE 1
// ============================================================

static void minerTask(void *pv) {

  Serial.printf(
    "[CORE1] Miner/Stratum START | core=%d | stack=%uB\n",
    xPortGetCoreID(),
    (unsigned)(uxTaskGetStackHighWaterMark(NULL) * sizeof(StackType_t))
  );

  Serial.println("[TEST] Validating PEPEW HooHash V110...");

  if(!validatePepew()) {
    Serial.println("[FATAL] PEPEW VECTOR FAIL - MINING STOPPED");
    for(;;)
      vTaskDelay(pdMS_TO_TICKS(1000));
  }

  Serial.println("[OK] PEPEW VECTOR PASS");
  hoohash_profile_reset();
  Serial.println("[PROFILE] Contadores reiniciados; midiendo primeras 256 muestras por core...");
  Serial.println("[V8.2] RITSA WIFI PORTAL + STABLE WEB dual-core: C0 odd / C1 even nonces");
  Serial.println("[V8.2] Saved WiFi + Setup AP + cached web image + GPIO48 + FAST-FACTOR");
  Serial.printf("[V6.1] CPU=%u MHz | Serial monitor ACTIVE @115200\n", ESP.getCpuFreqMHz());

  wifiConnect();

  // Ahora la red ya esta inicializada: STA conectado o AP de configuracion.
  // Solo aqui es seguro arrancar WebServer cuando habia WiFi guardado.
  if(WiFi.status()==WL_CONNECTED || wifiSetupMode) {
    Serial.println("[WEB] Network ready -> starting server...");
    startWebIfNeeded();
  }

  reportMs = millis();

  uint8_t cachedHeader[80] = {0};
  uint8_t target[32] = {0};
  uint8_t hash[32];

  String cachedJobId = "";
  String cachedExtra2 = "";
  double cachedDiff = -1.0;
  uint32_t localGeneration = 0;
  uint32_t nonce1 = 0;             // Core 1 = nonces pares

  for(;;) {

    if(WiFi.status() != WL_CONNECTED) {
      pool.stop();
      cachedJobId = "";
      if(!wifiSetupMode) wifiConnect();
      if((WiFi.status()==WL_CONNECTED || wifiSetupMode) && !webStarted) {
        startWebIfNeeded();
      }
      vTaskDelay(pdMS_TO_TICKS(100));
      continue;
    }

    poolConnect();
    readPool();

    if(pool.connected() && job.valid && extranonce1.length()) {

      // El header/merkle se reconstruye solamente al cambiar de JOB.
      if(cachedJobId != job.id) {
        String ex;

        if(buildHeader(cachedHeader, ex)) {
          cachedJobId = job.id;
          cachedExtra2 = ex;
          cachedDiff = -1.0;
          nonce1 = 0;

          Serial.printf(
            "[CACHE] Header ready | job=%s | branches=%d\n",
            cachedJobId.c_str(),
            job.branchCount
          );
        } else {
          cachedJobId = "";
          Serial.println("[WARN] buildHeader failed");
        }
      }

      // Nuevo target o nuevo header -> publicar snapshot para Core 0.
      if(cachedJobId.length() && cachedDiff != poolDifficulty) {
        makeTarget(poolDifficulty, target);
        cachedDiff = poolDifficulty;

        portENTER_CRITICAL(&workMux);
        memcpy(sharedHeader, cachedHeader, 80);
        memcpy(sharedTarget, target, 32);
        localGeneration = ++workGeneration;
        portEXIT_CRITICAL(&workMux);

        nonce1 = 0;

        Serial.printf(
          "[WORK] generation=%lu | diff=%.6f\n",
          (unsigned long)localGeneration,
          cachedDiff
        );
      }

      if(cachedJobId.length()) {
        const String activeJob = cachedJobId;

        for(int i = 0; i < 32 && pool.connected(); i++) {

          if(job.id != activeJob)
            break;

          uint32_t n = nonce1;
          nonce1 += 2;

          putNonce(cachedHeader, n);
          hoohashv110_ctx(0, cachedHeader, 80, hash);
          core1Hashes++;

          if(hashMeets(hash, target)) {
            Serial.print("[FOUND-C1] hash=");
            printHex(hash, 32);
            submitShare(n, cachedExtra2);
          }

          if((i & 15) == 15) {
            readPool();
            // Cedemos un tick real para mantener estable el watchdog
            // sin volver al rendimiento de la version de un solo core.
            vTaskDelay(1);
          }
        }
      }
    }

    // Shares encontradas por Core 0 se envian desde Core 1,
    // que es el unico nucleo que toca Stratum para submit.
    FoundShare fs;
    while(foundQueue && xQueueReceive(foundQueue, &fs, 0) == pdTRUE) {
      if(fs.generation == localGeneration && cachedJobId == job.id) {
        Serial.printf(
          "[FOUND-C0] nonce=%08lx\n",
          (unsigned long)fs.nonce
        );
        submitShare(fs.nonce, cachedExtra2);
      }
    }

    uint32_t now = millis();

    if(now - reportMs >= 5000) {
      uint32_t elapsed = now - reportMs;
      uint64_t combined = core0Hashes + core1Hashes;
      uint64_t delta = combined - reportHashes;

      currentHashrate =
        (float)delta * 1000.0f / (float)elapsed;

      totalHashes = combined;

      Serial.printf(
        "[MINER-V6.2] %.2f H/s | C0=%llu C1=%llu | total=%llu | A=%llu R=%llu | diff=%.3f | RAM=%uKB | stack=%uB\n",
        currentHashrate,
        core0Hashes,
        core1Hashes,
        combined,
        accepted,
        rejected,
        poolDifficulty,
        ESP.getFreeHeap() / 1024,
        (unsigned)(uxTaskGetStackHighWaterMark(NULL) * sizeof(StackType_t))
      );

      static bool profilePrinted = false;
      if(!profilePrinted) {
        hoohash_profile_t p0, p1;
        hoohash_profile_get(0, &p0);
        hoohash_profile_get(1, &p1);
        if(p0.samples >= 256 && p1.samples >= 256) {
          uint64_t n = (uint64_t)p0.samples + p1.samples;
          uint64_t fb = p0.first_blake_us + p1.first_blake_us;
          uint64_t mm = p0.matrix_math_us + p1.matrix_math_us;
          uint64_t lb = p0.final_blake_us + p1.final_blake_us;
          uint64_t tt = p0.total_us + p1.total_us;
          Serial.println("\n========== V5 HOOHASH PROFILE ==========");
          Serial.printf("samples       : %llu\n", (unsigned long long)n);
          Serial.printf("first BLAKE3  : %.2f us/hash | %.1f%%\n", (double)fb/n, tt ? (100.0*(double)fb/(double)tt) : 0.0);
          Serial.printf("matrix + math : %.2f us/hash | %.1f%%\n", (double)mm/n, tt ? (100.0*(double)mm/(double)tt) : 0.0);
          Serial.printf("final BLAKE3  : %.2f us/hash | %.1f%%\n", (double)lb/n, tt ? (100.0*(double)lb/(double)tt) : 0.0);
          Serial.printf("TOTAL HooHash : %.2f us/hash\n", (double)tt/n);
          Serial.printf("theoretical/core from measured HooHash: %.2f H/s\n", tt ? (1000000.0/((double)tt/n)) : 0.0);
          Serial.printf("matrix rebuild C0: %lu x, avg %.2f us\n", (unsigned long)p0.matrix_rebuilds, p0.matrix_rebuilds ? (double)p0.matrix_rebuild_us/p0.matrix_rebuilds : 0.0);
          Serial.printf("matrix rebuild C1: %lu x, avg %.2f us\n", (unsigned long)p1.matrix_rebuilds, p1.matrix_rebuilds ? (double)p1.matrix_rebuild_us/p1.matrix_rebuilds : 0.0);
          Serial.println("========================================\n");
          profilePrinted = true;
        }
      }

      reportHashes = combined;
      reportMs = now;
    }

    readPool();
    vTaskDelay(1);
  }
}

// ============================================================
//                           SETUP
// ============================================================

static bool initSDCard() {
  Serial.println("[SD] Starting onboard microSD: CS=4 MISO=5 MOSI=6 SCLK=7...");
  sdSPI.begin(SD_SCLK, SD_MISO, SD_MOSI, SD_CS);
  if(!SD.begin(SD_CS, sdSPI, 10000000)) {
    Serial.println("[SD] NOT FOUND - miner will continue without full dashboard");
    sdOK=false;
    return false;
  }
  uint8_t type=SD.cardType();
  if(type==CARD_NONE) {
    Serial.println("[SD] No card inserted");
    sdOK=false;
    return false;
  }
  sdOK=true;
  Serial.printf("[SD] OK | %.1f MB total | %.1f MB used\n",
    SD.totalBytes()/1048576.0, SD.usedBytes()/1048576.0);
  if(!SD.exists("/www")) SD.mkdir("/www");
  return true;
}

void setup() {

  Serial.begin(
    115200
  );

  delay(1500);

  Serial.println("[SERIAL] Monitor activo a 115200 baud");
  Serial.println("[SERIAL] Copia desde el arranque hasta varios [MINER-V6.2]");

  Serial.println();
  Serial.println(
    "========================================"
  );

  Serial.println(
    " PEPEW ESP32-S3 V8.2"
  );

  Serial.println(
    " DUAL CORE + DUAL DISPLAY BUILD"
  );

  Serial.println(
    "========================================"
  );

  Serial.printf(
    "CPU: %u MHz\n",
    ESP.getCpuFreqMHz()
  );

  Serial.printf(
    "RAM: %u KB\n",
    ESP.getFreeHeap() / 1024
  );

  // ==========================================================
  //        NVS / PREFERENCES - INIT BEFORE DISPLAY DRIVERS
  // ==========================================================
  // V8.2: se inicializa NVS/Preferences al principio del arranque.
  // Esto evita intentar tomar un mutex/semaforo de NVS despues de
  // inicializar TFT/OLED y hace el arranque mas determinista.
  Serial.println("[BOOT] Initializing NVS...");
  esp_err_t nvsErr = nvs_flash_init();
  if(nvsErr == ESP_ERR_NVS_NO_FREE_PAGES || nvsErr == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    Serial.println("[BOOT] NVS needs recovery - erasing NVS...");
    ESP_ERROR_CHECK(nvs_flash_erase());
    nvsErr = nvs_flash_init();
  }
  if(nvsErr != ESP_OK) {
    Serial.printf("[FATAL] nvs_flash_init failed: %s\n", esp_err_to_name(nvsErr));
    delay(3000);
    ESP.restart();
  }
  Serial.println("[BOOT] NVS OK");

  Serial.println("[BOOT] Opening Preferences namespace...");
  if(!prefs.begin("ritsa", false)) {
    Serial.println("[FATAL] Preferences begin failed");
    delay(3000);
    ESP.restart();
  }
  Serial.println("[BOOT] Preferences OK");

  savedWifiSsid = prefs.getString("wifiSsid", "");
  savedWifiPassword = prefs.getString("wifiPass", "");
  ritsaMessage = prefs.getString("tickerMsg", "RITSA ELECTRONICA");
  ritsaEnabled = prefs.getBool("tickerOn", true);
  if(ritsaMessage.length()==0) ritsaMessage="RITSA ELECTRONICA";
  Serial.printf("[BOOT] Saved WiFi: %s\n", savedWifiSsid.length() ? "YES" : "NO");

  // microSD contiene dashboard, portal, CSS, JS e imagenes.
  // Si falla, la mineria sigue y queda disponible el portal WiFi de emergencia.
  initSDCard();

  // ==========================================================
  //                       TFT
  // ==========================================================

  Serial.println(
    "[TFT] Starting GC9A01..."
  );

  // MISMA configuración que ya comprobamos
  tft.begin(
    10000000
  );

  tft.setRotation(
    0
  );

  tft.fillScreen(
    GC9A01A_BLACK
  );

  drawPepeMiner(
    0
  );

  Serial.println(
    "[TFT] OK"
  );

  // ==========================================================
  //                       OLED
  // ==========================================================

  Serial.println(
    "[OLED] Starting I2C GPIO1/GPIO2..."
  );

  Wire.begin(
    OLED_SDA,
    OLED_SCL
  );

  Wire.setClock(
    400000
  );

  oledOK =
    oled.begin(
      SSD1306_SWITCHCAPVCC,
      0x3C
    );

  if(oledOK) {

    // Orientacion correcta para el montaje fisico de Ritsa Crypto Miner.
    // OLED girada 180 grados para la orientacion fisica correcta.
    oled.setRotation(2);

    Serial.println(
      "[OLED] SSD1306 OK @ 0x3C"
    );

    oled.clearDisplay();

    oled.setTextColor(
      SSD1306_WHITE
    );

    oled.setTextSize(
      1
    );

    oled.setCursor(
      0,
      0
    );

    oled.println(
      "PEPEW MINER"
    );

    oled.println(
      "ESP32-S3"
    );

    oled.println();
    oled.println(
      "Starting..."
    );

    oled.display();

  } else {

    Serial.println(
      "[OLED] NOT FOUND"
    );

    Serial.println(
      "[OLED] Check 0x3C/0x3D"
    );
  }

  Serial.println("[BOOT] Configuring GPIO48...");
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  lastButtonReading = digitalRead(BUTTON_PIN);
  stableButtonState = lastButtonReading;
  lastButtonEdge = millis();
  lastButtonActivity = millis();

  Serial.println("[BOOT] GPIO48 ready");

  Serial.println("[BOOT] Registering web routes...");
  setupWebRoutes();
  Serial.println("[BOOT] Web routes OK");

  // IMPORTANTE V8.2:
  // NO iniciar WebServer hasta que exista una interfaz WiFi activa.
  // En V7.1/V7.2 webServer.begin() se ejecutaba aun con WiFi sin inicializar
  // cuando habia credenciales guardadas. Eso podia terminar en
  // xQueueSemaphoreTake(pxQueue) por un objeto interno de red no listo.
  if(savedWifiSsid.length()==0) {
    Serial.println("[BOOT] No saved WiFi -> starting setup AP...");
    startSetupAP();
    Serial.println("[BOOT] Setup AP OK -> starting web server...");
    startWebIfNeeded();
  } else {
    Serial.println("[BOOT] Saved WiFi present -> web server waits for STA connection");
  }

  Serial.println("[BUTTON] GPIO48 INPUT_PULLUP polling ready");
  Serial.printf("[OLED] Ticker %s: %s\n", ritsaEnabled?"ON":"OFF", ritsaMessage.c_str());

  // ==========================================================
  //             DISPLAY + DUAL CORE MINING TASKS
  // ==========================================================

  foundQueue = xQueueCreate(8, sizeof(FoundShare));

  if(!foundQueue)
    Serial.println("[FATAL] foundQueue creation failed");

  BaseType_t buttonOK =
    xTaskCreatePinnedToCore(
      buttonTask,
      "buttonTask",
      3072,
      NULL,
      3,
      NULL,
      0
    );

  BaseType_t webOK =
    xTaskCreatePinnedToCore(
      webTask,
      "ritsaWeb",
      6144,
      NULL,
      1,
      &webTaskHandle,
      1
    );

  BaseType_t displayOK =
    xTaskCreatePinnedToCore(
      displayTask,
      "displayTask",
      8192,
      NULL,
      1,
      NULL,
      0
    );

  BaseType_t core0OK =
    xTaskCreatePinnedToCore(
      hashWorker0,
      "pepewHash0",
      32768,
      NULL,
      2,
      NULL,
      0
    );

  BaseType_t minerOK =
    xTaskCreatePinnedToCore(
      minerTask,
      "pepewMiner1",
      49152,
      NULL,
      2,
      NULL,
      1
    );

  Serial.printf(
    "[TASKS] button=%s | web=%s | display=%s | hashCore0=%s | minerCore1=%s\n",
    buttonOK == pdPASS ? "OK" : "FAIL",
    webOK == pdPASS ? "OK" : "FAIL",
    displayOK == pdPASS ? "OK" : "FAIL",
    core0OK == pdPASS ? "OK" : "FAIL",
    minerOK == pdPASS ? "OK" : "FAIL"
  );
}

// ============================================================
//                            LOOP
// ============================================================

void loop() {

  vTaskDelay(
    pdMS_TO_TICKS(1000)
  );
}