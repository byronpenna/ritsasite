RITSA PEPEW MINER V8.2 - WEB STABLE

Cambios frente a V8.1:
- Servidor HTTP movido a tarea dedicada ritsaWeb.
- ritsaWeb: Core 1, prioridad 1, stack 6144.
- Mineros siguen prioridad 2; HooHash/FAST-FACTOR no se modifica.
- displayTask ya no atiende peticiones HTTP.
- Dashboard completo sigue en microSD.
- /api/stats sigue ligero y la grafica se procesa en el navegador.
- Diagnostico cada 30 s:
  [WEB-DIAG] requests=... stats=... free=... min=... largest=...
- microSD: CS=4 MISO=5 MOSI=6 SCLK=7.

Para SD: copie el CONTENIDO de SD_CARD a la raiz de la tarjeta.
Debe quedar /www/index.html, /www/style.css, /www/app.js, etc.
