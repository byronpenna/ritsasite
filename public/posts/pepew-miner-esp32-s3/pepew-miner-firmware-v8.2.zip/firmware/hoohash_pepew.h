#ifndef HOOHASH_PEPEW_H
#define HOOHASH_PEPEW_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define HOOHASH_HASH_SIZE 32
#define HOOHASH_PROFILE_API_V51 1

typedef struct {
  uint32_t samples;
  uint64_t first_blake_us;
  uint64_t matrix_math_us;
  uint64_t final_blake_us;
  uint64_t total_us;
  uint32_t matrix_rebuilds;
  uint64_t matrix_rebuild_us;
} hoohash_profile_t;

void hoohashv110(const void *data, size_t len, uint8_t output[HOOHASH_HASH_SIZE]);
void hoohashv110_ctx(uint8_t ctx, const void *data, size_t len, uint8_t output[HOOHASH_HASH_SIZE]);
void hoohash_profile_reset(void);
void hoohash_profile_get(uint8_t ctx, hoohash_profile_t *out);

#ifdef __cplusplus
}
#endif
#endif
