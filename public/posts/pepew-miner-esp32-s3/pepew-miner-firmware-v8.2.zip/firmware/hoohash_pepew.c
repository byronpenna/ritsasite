#include "hoohash_pepew.h"
#include "blake3.h"
#include <string.h>
#include <math.h>
#include "esp_timer.h"

#define PI 3.14159265358979323846
#define EPS 1e-9
#define COMPLEX_TRANSFORM_MULTIPLIER 0.000001

typedef struct { uint64_t s0,s1,s2,s3; } xoshiro_state;

typedef struct {
  uint8_t valid;
  uint8_t seed[32];
  double mat[64][64];
  hoohash_profile_t prof;
} hoohash_ctx_t;

static hoohash_ctx_t gctx[2];

static inline uint64_t now_us(void){ return (uint64_t)esp_timer_get_time(); }
static inline uint64_t read_uint64_le(const uint8_t *d){uint64_t r=0;for(int i=0;i<8;i++)r|=((uint64_t)d[i])<<(i*8);return r;}
static inline uint32_t read_uint32_le(const uint8_t*d){return ((uint32_t)d[0])|((uint32_t)d[1]<<8)|((uint32_t)d[2]<<16)|((uint32_t)d[3]<<24);}
static inline uint32_t read_uint32_be(const uint8_t*d){return ((uint32_t)d[0]<<24)|((uint32_t)d[1]<<16)|((uint32_t)d[2]<<8)|(uint32_t)d[3];}
static inline uint64_t rotl64(uint64_t x,int k){return (x<<k)|(x>>(64-k));}
static void xoshiro_init(xoshiro_state*s,const uint8_t*b){s->s0=read_uint64_le(b);s->s1=read_uint64_le(b+8);s->s2=read_uint64_le(b+16);s->s3=read_uint64_le(b+24);}
static uint64_t xoshiro_gen(xoshiro_state*x){uint64_t r=rotl64(x->s0+x->s3,23)+x->s0;uint64_t t=x->s1<<17;x->s2^=x->s0;x->s3^=x->s1;x->s1^=x->s2;x->s0^=x->s3;x->s2^=t;x->s3=rotl64(x->s3,45);return r;}

static double MediumComplexNonLinear(double x){return exp(sin(x)+cos(x));}
static double IntermediateComplexNonLinear(double x){if(fabs(x-PI/2)<EPS||fabs(x-3*PI/2)<EPS)return 0;return sin(x)*sin(x);}
static double HighComplexNonLinear(double x){return 1.0/sqrt(fabs(x)+1);}
static double ComplexNonLinear(double x){
  double a=(x*COMPLEX_TRANSFORM_MULTIPLIER)/8.0-floor((x*COMPLEX_TRANSFORM_MULTIPLIER)/8.0);
  double b=(x*COMPLEX_TRANSFORM_MULTIPLIER)/4.0-floor((x*COMPLEX_TRANSFORM_MULTIPLIER)/4.0);
  if(a<0.33){if(b<0.25)return MediumComplexNonLinear(x+(1+b));else if(b<0.5)return MediumComplexNonLinear(x-(1+b));else if(b<0.75)return MediumComplexNonLinear(x*(1+b));else return MediumComplexNonLinear(x/(1+b));}
  else if(a<0.66){if(b<0.25)return IntermediateComplexNonLinear(x+(1+b));else if(b<0.5)return IntermediateComplexNonLinear(x-(1+b));else if(b<0.75)return IntermediateComplexNonLinear(x*(1+b));else return IntermediateComplexNonLinear(x/(1+b));}
  else {if(b<0.25)return HighComplexNonLinear(x+(1+b));else if(b<0.5)return HighComplexNonLinear(x-(1+b));else if(b<0.75)return HighComplexNonLinear(x*(1+b));else return HighComplexNonLinear(x/(1+b));}
}
static double SafeComplexTransform(double input){double v=ComplexNonLinear(input),rounds=1;while(isnan(v)||isinf(v)){input*=0.1;if(input<=1e-13)return 0;rounds++;v=ComplexNonLinear(input);}return v*rounds;}
static void generateHoohashMatrix(const uint8_t*hash,double mat[64][64]){xoshiro_state s;xoshiro_init(&s,hash);for(int i=0;i<64;i++)for(int j=0;j<64;j++){uint64_t v=xoshiro_gen(&s);uint32_t lo=v&0xffffffffu;mat[i][j]=(double)lo/(double)UINT32_MAX*1000000.0;}}

/* V6 FAST-FACTOR: product is non-negative here, so truncation is equivalent to floor
   and avoids the expensive libm floor() in the hottest inner loop. */
static inline double TransformFactor(double x){
  double y=x*(1.0/1024.0);
  return y-(double)((uint64_t)y);
}
static void ConvertBytesToUint32Array(uint32_t*H,const uint8_t*b){for(int i=0;i<8;i++)H[i]=read_uint32_be(b+i*4);}

static void HoohashMatrixMultiplication(double mat[64][64],const uint8_t*hashBytes,uint8_t*output,uint64_t nonce){
  uint8_t scaled[32]={0},vector[64]={0},result[32]={0};double product[64]={0};uint32_t H[8]={0};
  ConvertBytesToUint32Array(H,hashBytes);double hashXor=(double)(H[0]^H[1]^H[2]^H[3]^H[4]^H[5]^H[6]^H[7]);double nonceMod=(double)(nonce&0xff);double sw=0.0;
  for(int i=0;i<32;i++){vector[2*i]=hashBytes[i]>>4;vector[2*i+1]=hashBytes[i]&0x0f;}
  for(int i=0;i<64;i++){for(int j=0;j<64;j++){if(sw<=0.02){double in=mat[i][j]*hashXor*(double)vector[j]+nonceMod;product[i]+=SafeComplexTransform(in)*(double)vector[j]*1234.0;}else product[i]+=mat[i][j]*0.0001*(double)vector[j];sw=TransformFactor(product[i]);}}
  for(int i=0;i<64;i+=2){uint64_t p=(uint64_t)product[i]+(uint64_t)product[i+1];scaled[i/2]=(uint8_t)(p&0xff);}
  for(int i=0;i<32;i++)result[i]=hashBytes[i]^scaled[i];
  blake3_hasher h;blake3_hasher_init(&h);blake3_hasher_update(&h,result,32);blake3_hasher_finalize(&h,output,32);
}

void hoohash_profile_reset(void){
  for(int i=0;i<2;i++) memset(&gctx[i].prof,0,sizeof(gctx[i].prof));
}
void hoohash_profile_get(uint8_t ctx, hoohash_profile_t *out){
  if(!out) return; ctx &= 1; memcpy(out,&gctx[ctx].prof,sizeof(*out));
}

void hoohashv110_ctx(uint8_t ctx,const void*data,size_t len,uint8_t output[32]){
  if(len!=80){memset(output,0,32);return;}
  ctx &= 1;
  hoohash_ctx_t *c=&gctx[ctx];
  const uint8_t*d=(const uint8_t*)data;
  blake3_hasher h; uint8_t first[32],seed[32],masked[80];
  uint64_t t0=now_us(),t1,t2,t3;

  blake3_hasher_init(&h);blake3_hasher_update(&h,d,80);blake3_hasher_finalize(&h,first,32);
  t1=now_us();

  memcpy(masked,d,80);memset(masked+76,0,4);
  blake3_hasher_init(&h);blake3_hasher_update(&h,masked,80);blake3_hasher_finalize(&h,seed,32);
  if(!c->valid || memcmp(c->seed,seed,32)!=0){
    uint64_t mr0=now_us();
    generateHoohashMatrix(seed,c->mat);
    uint64_t mr1=now_us();
    memcpy(c->seed,seed,32); c->valid=1;
    c->prof.matrix_rebuilds++;
    c->prof.matrix_rebuild_us += mr1-mr0;
  }

  uint64_t nonce=(uint64_t)read_uint32_le(d+76);
  /* Keep final BLAKE timing separable by inlining the same math body here. */
  uint8_t scaled[32]={0},vector[64]={0},result[32]={0};double product[64]={0};uint32_t H[8]={0};
  ConvertBytesToUint32Array(H,first);double hashXor=(double)(H[0]^H[1]^H[2]^H[3]^H[4]^H[5]^H[6]^H[7]);double nonceMod=(double)(nonce&0xff);double sw=0.0;
  for(int i=0;i<32;i++){vector[2*i]=first[i]>>4;vector[2*i+1]=first[i]&0x0f;}
  for(int i=0;i<64;i++){for(int j=0;j<64;j++){if(sw<=0.02){double in=c->mat[i][j]*hashXor*(double)vector[j]+nonceMod;product[i]+=SafeComplexTransform(in)*(double)vector[j]*1234.0;}else product[i]+=c->mat[i][j]*0.0001*(double)vector[j];sw=TransformFactor(product[i]);}}
  for(int i=0;i<64;i+=2){uint64_t p=(uint64_t)product[i]+(uint64_t)product[i+1];scaled[i/2]=(uint8_t)(p&0xff);}
  for(int i=0;i<32;i++)result[i]=first[i]^scaled[i];
  t2=now_us();

  blake3_hasher_init(&h);blake3_hasher_update(&h,result,32);blake3_hasher_finalize(&h,output,32);
  t3=now_us();

  c->prof.samples++;
  c->prof.first_blake_us += t1-t0;
  c->prof.matrix_math_us += t2-t1;
  c->prof.final_blake_us += t3-t2;
  c->prof.total_us += t3-t0;
}

void hoohashv110(const void*data,size_t len,uint8_t output[32]){
  hoohashv110_ctx(0,data,len,output);
}
