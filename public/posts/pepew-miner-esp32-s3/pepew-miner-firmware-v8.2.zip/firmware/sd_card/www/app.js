const $=id=>document.getElementById(id);
const hist=[]; const MAX_POINTS=72;
let sum=0, peak=0;
function fmt(n){return Number(n||0).toLocaleString()}
function uptime(s){s=Number(s||0);let d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60);return (d?d+"d ":"")+h+"h "+m+"m"}
function draw(){
 const c=$("hashChart"),dpr=window.devicePixelRatio||1,w=c.clientWidth,h=c.clientHeight;
 c.width=w*dpr;c.height=h*dpr;const x=c.getContext("2d");x.scale(dpr,dpr);x.clearRect(0,0,w,h);
 const pad=32,lo=hist.length?Math.max(0,Math.min(...hist)-4):0,hi=hist.length?Math.max(105,Math.max(...hist)+4):105;
 x.strokeStyle="#164b53";x.lineWidth=1;x.fillStyle="#789fa2";x.font="11px Arial";
 for(let i=0;i<5;i++){let y=pad+(h-pad*2)*i/4;x.beginPath();x.moveTo(pad,y);x.lineTo(w-8,y);x.stroke();let v=hi-(hi-lo)*i/4;x.fillText(v.toFixed(0),2,y+4)}
 if(hist.length<2)return;
 x.strokeStyle="#ffc928";x.lineWidth=2.5;x.beginPath();
 hist.forEach((v,i)=>{let px=pad+(w-pad-10)*i/(MAX_POINTS-1),py=pad+(hi-v)/(hi-lo)*(h-pad*2);i?x.lineTo(px,py):x.moveTo(px,py)});x.stroke();
}
async function refresh(){
 try{
  let r=await fetch("/api/stats",{cache:"no-store"});if(!r.ok)throw 0;let j=await r.json();
  let hv=Number(j.hashrate||0); $("h").textContent=hv.toFixed(2);$("chartNow").textContent=hv.toFixed(2);
  $("t").textContent=fmt(j.totalHashes);$("a").textContent=j.accepted;$("r").textContent=j.rejected;
  $("l").textContent=j.lastShare;$("d").textContent=j.difficulty;$("w").textContent=j.wifiRssi+" dBm";$("u").textContent=uptime(j.uptime);
  let b=$("poolBadge");b.textContent=j.pool?"POOL ONLINE":"POOL OFFLINE";b.className="badge "+(j.pool?"ok":"bad");
  hist.push(hv);if(hist.length>MAX_POINTS)hist.shift();sum=hist.reduce((a,b)=>a+b,0);peak=Math.max(...hist);
  $("avg").textContent=(sum/hist.length).toFixed(2);$("max").textContent=peak.toFixed(2);draw();
 }catch(e){let b=$("poolBadge");b.textContent="SIN DATOS";b.className="badge bad"}
}
document.querySelectorAll("[data-p]").forEach(b=>b.onclick=()=>fetch("/api/oled-page",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({page:b.dataset.p})}));
window.addEventListener("resize",draw);refresh();setInterval(refresh,5000);